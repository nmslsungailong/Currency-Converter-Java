package Java;

import java.net.URI;

import com.mashape.unirest.request.HttpRequest;

public class Main {
	public static void main(String[] args) {
		GUI frame = new GUI();
		
	}
}
